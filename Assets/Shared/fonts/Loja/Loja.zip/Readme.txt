Thanks for download
License: free for personal and commercial use.

Visit AmruID font collection:
https://font.amru.id/

Personal blog
https://amru.id/