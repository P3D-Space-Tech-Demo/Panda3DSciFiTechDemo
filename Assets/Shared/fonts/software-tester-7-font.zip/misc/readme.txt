
True Type Font: Software Tester 7 version 1.0


EULA
-==-
The font Software Tester 7 is freeware.


DESCRIPTION
-=========-
Thin, square and monospaced sans serif font.

Files in software_tester_7.zip:
       	readme.txt     				this file;
        software_tester_7.ttf 			regular font;
	software_tester_7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: December 19 2013